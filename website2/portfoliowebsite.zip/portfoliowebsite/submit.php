<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // Your email address where the form submissions will be sent
    $to = "timvanderwulp@hotmail.nl";

    // Subject for the email
    $subject = "New Contact Form Submission";

    // Email content
    $email_content = "Name: $name\n";
    $email_content .= "Email: $email\n";
    $email_content .= "Message:\n$message";

    // Additional headers
    $headers = "From: $email\n";

    // Send the email
    mail($to, $subject, $email_content, $headers);

    // Optionally, you can redirect the user or display a success message
    echo "Email sent successfully!";
} else {
    // If the form is not submitted using POST method, redirect to the form page
    header("Location: index.html");
}
?>
