document.addEventListener("DOMContentLoaded", function() {
    let attempts = 0;

    function getRandomPokemon() {
        const generation = document.getElementById('generation').value;
        const url = `https://pokeapi.co/api/v2/generation/${generation}/`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                const pokemonSpecies = data.pokemon_species;
                const randomPokemon = pokemonSpecies[Math.floor(Math.random() * pokemonSpecies.length)];
                const pokemonId = parseInt(randomPokemon.url.split('/')[6]);

                // Display the information of the current Pokémon
                displayPokemonInfo(pokemonId);

                // Get the input element reference outside of the event listener
                var input = document.getElementById("vulin");

                // Add event listener outside of the fetch to avoid repeated listeners
                input.addEventListener("keypress", function(event) {
                    // If the user presses the "Enter" key on the keyboard
                    if (event.key === "Enter") {
                        // Add logic to check if the entered Pokémon name is correct
                        const enteredName = input.value.toLowerCase(); // Convert to lowercase for case-insensitive comparison

                        // Fetch the details of the current Pokémon to get its name
                        const pokemonDetailsUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonId}/`;
                        fetch(pokemonDetailsUrl)
                            .then(response => response.json())
                            .then(pokemonData => {
                                const currentPokemonName = pokemonData.name;

                                if (enteredName === currentPokemonName) {
                                    attempts = 0; // Reset attempts
                                    getRandomPokemon(); // Load another random Pokémon
                                    input.value = ''; // Clear the input field
                                } else {
                                    attempts++;

                                    if (attempts === 3) {
                                        // Display the Pokémon name after 3 attempts
                                        console.log('The correct Pokémon name is:', currentPokemonName);
                                        attempts = 0; // Reset attempts
                                        getRandomPokemon(); // Load another random Pokémon
                                        input.value = ''; // Clear the input field
                                    } else {
                                        // Incorrect Pokémon name entered, you can add error handling here
                                        console.log('Incorrect Pokémon name entered');
                                    }
                                }
                            })
                            .catch(error => {
                                console.error('Error fetching Pokémon details:', error);
                            });
                    }
                });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    function displayPokemonInfo(pokemonId) {
        const pokemonInfoDiv = document.getElementById('pokemon-info');
        const pokemonImageElement = document.getElementById('pokemon-image');
        
        const spriteUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemonId}.png`;
        
        pokemonInfoDiv.style.display = 'block';
        pokemonImageElement.src = spriteUrl;
    }

    // Load the first random Pokémon initially
    getRandomPokemon();
});
