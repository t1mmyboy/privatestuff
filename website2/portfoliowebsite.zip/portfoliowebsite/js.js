var oldScrollY = window.scrollY;
      var header = document.getElementById("totop");
      window.onscroll = function(e) {
        console.log(oldScrollY)
        if(oldScrollY < 100){
            
            header.style.display = "none"
        } else {
            header.style.display = "flex"
        }
        oldScrollY = window.scrollY;
      }
      var acc = document.getElementsByClassName("accordion");
      var i;
      
      for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
          /* Toggle between adding and removing the "active" class,
          to highlight the button that controls the panel */
          this.classList.toggle("active");
      
          /* Toggle between hiding and showing the active panel */
          var panel = this.nextElementSibling;
          if (panel.style.display === "block") {
            panel.style.display = "none";
          } else {
            panel.style.display = "block";
          }
        });
      }

       // Array of random facts
  var factsArray = [
    "Mestkevers (Dung beetles) Gebruiken de sterren om zich te positioneren. Door competitie met andere mestkevers moeten ze zo snel mogelijk met een bol mest wegrollen, en de snelste manier om te reizen is in een rechte lijn dus kijken ze naar de sterren om in een rechte lijn te lopen. Als het bewolkt is gaan ze dus ook zigzaggen omdat ze zich niet recht kunnen houden",
    "Uilen hebben geen oogballen, ze hebben oog cylinders. Daarom kunnen ze hun nek zo veel bewegen omdat ze alleen maar recht vooruit kunnen kijken",
    "Amfibieën hebben een doorlaatbare huid, Dat betekent dat ze stoffen heel makkelijk door hun huid absorberen. Dat is heel handig als je bijvoorbeeld water of lucht absorbeerd, maar veel minder handig als je ineens zeep of andere soorten giftige stoffen in je lichaam krijgt. Daarom altijd amfibieën aanraken met handschoenen of goed je handen wassen met water!",
    "Bekerplanten zijn vleesetende planten, ze werken doordat ze vliegen aantrekken doormiddel van geuren. Vervolgens met hun soort nectar zorgen ze ervoor dat de vlieg 'Dronken' wordt en valt hij in de beker. Doordat de binnenkant zo glad is kunnen ze er niet uit klimmen en worden ze langzaam opgelost in de maagzuren van de plant.",
    "Glaskikkers zoals de naam al kan verklappen zijn aan de onderkant van hun lichaam doorzichtig, dus kan je hun organen zien, hun hart zien kloppen en hun bloedvaten zien stromen",
    "Vleermuizen zijn de enige zoogdieren die echt kunnen vliegen. Ze gebruiken echolocatie om in het donker te navigeren en voedsel te vinden. De geluidsgolven die ze uitzenden, kaatsen terug van objecten, waardoor ze een mentale kaart van hun omgeving kunnen maken.",
    "Kameleons kunnen hun ogen onafhankelijk van elkaar bewegen. Hierdoor kunnen ze 360 graden om zich heen kijken zonder hun hoofd te bewegen. Het helpt hen bij het spotten van prooien en het vermijden van roofdieren.",
    "Sommige vogelsoorten, zoals papegaaien en kraaien, hebben het vermogen om menselijke spraak na te bootsen. Ze kunnen woorden en zinnen leren en herhalen, waardoor ze fascinerende metgezellen zijn.",
    "Zeekomkommers hebben de opmerkelijke eigenschap om hun ingewanden uit te werpen als een afleidingsmanoeuvre tegen roofdieren. Gelukkig kunnen ze deze inwendige organen regenereren, en ze groeien na verloop van tijd weer aan.",
    "Octopussen hebben drie harten. Twee harten pompen bloed naar de kieuwen, en het derde hart pompt het zuurstofrijke bloed door het hele lichaam. Deze complexe bloedsomloop draagt bij aan hun buitengewone intelligentie en aanpassingsvermogen."
  ];

  function showRandomFact() {
    if (factsArray.length+1 > 0) {
      // Get a random index from the factsArray
      var randomIndex = Math.floor(Math.random() * factsArray.length);

      // Display the random fact in the paragraph with id "factDisplay"
      document.getElementById("factDisplay").textContent = factsArray[randomIndex];

      // Remove the displayed fact from the array
      factsArray.splice(randomIndex, 1);

      // Check if the array is empty

    }if(document.getElementById("factDisplay").textContent == "" ){document.getElementById("factDisplay").textContent = "Dat waren alle feiten!";
    document.querySelector("button").disabled = true; // Disable the button when there are no more facts}
  }
}
var acc = document.getElementsByClassName("project-accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    /* Toggle between adding and removing the "active" class,
    to highlight the button that controls the panel */
    this.classList.toggle("active");

    /* Toggle between hiding and showing the active panel */
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}